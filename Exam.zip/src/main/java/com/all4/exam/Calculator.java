package com.all4.exam;

public class Calculator {
	public int addition(int n1, int n2) {
		System.out.println("Addition()");
		System.out.println(n1+"+"+n2+"="+(n1+n2));
		return n1+n2;
	}
	public double subtraction(int n1, int n2) {
		System.out.println("Subtraction()");
		System.out.println(n1+"-"+n2+"="+(n1-n2));
		return n1-n2;
	}
	public int multiplication(int n1, int n2) {
		System.out.println("Multiplication()");
		System.out.println(n1+"*"+n2+"="+(n1*n2));
		return n1*n2;
	}
	public int division(int n1, int n2) {
		System.out.println("Division()");
		System.out.println(n1+"/"+n2+"="+(n1/n2));
		return n1/n2;
	}
}
